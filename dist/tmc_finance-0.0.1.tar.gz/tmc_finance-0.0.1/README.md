# Tech & Media Club Financial Position Summary Creation Package

## Executive Summary
The package creates an excel file including six sheets and three plots which provide insight into the club's financial position
